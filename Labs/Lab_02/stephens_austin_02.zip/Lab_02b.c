#include <stdio.h>

int main()
{
	long double lngd;
	
	printf("Long doubles use %lu bytes of memory.", sizeof(lngd));
	
	return 0;
}
