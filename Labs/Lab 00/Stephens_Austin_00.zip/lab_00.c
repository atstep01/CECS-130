/*******************/
/* Austin Stephens */
/* CECS-130-01     */
/* Lab 00          */
/*******************/

#include <stdio.h>

main()
{
	printf("Hello CESC 130-01\n");
	system("pause");
}
