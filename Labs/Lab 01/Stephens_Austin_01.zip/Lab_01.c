/*******************/
/* Austin Stephens */
/* CECS-130-01     */
/* Lab 01          */
/*******************/

#include <stdio.h>

int main()

{
	int feet, cm;
	 
	feet = 1;
	
	cm = feet * 30;
	
	printf("%d feet is %d centimeters\n", feet, cm);
	
	
	
	feet = 3;
	
	cm = feet * 30;
	
	printf("%d feet is %d centimeters\n", feet, cm);
	
	feet = 6;
	
	cm = feet * 30;
	
	printf("%d feet is %d centimeters", feet, cm);
	
	return 0;
}
