/*******************/
/* Austin Stephens */
/* CECS-130-01     */
/*  Problem 01     */
/*******************/

#include <stdio.h>

int main()

{
	int a, b, x, y;
	a = 5;
	b = 1;
	x = 10;
	y = 5;
	int answer = (a-b)*(x-y);
	
	printf("%d", answer);
	
	return 0;
}
