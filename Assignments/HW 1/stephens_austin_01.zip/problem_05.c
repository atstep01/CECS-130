/*******************/
/* Austin Stephens */
/* CECS-130-01     */
/*  Problem 05     */
/*******************/

#include <stdio.h>

int main()

{
	printf("\"Keep your eyes on the stars, and your feet on the ground.\" -Theodore Roosevelt");
	return 0;
}
