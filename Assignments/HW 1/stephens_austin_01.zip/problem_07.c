/*******************/
/* Austin Stephens */
/* CECS-130-01     */
/*  Problem 07     */
/*******************/

#include <stdio.h>

int main()
{
	printf("        *    \n");
	printf("      *   *   \n");
	printf("    *       *  \n");
	printf("  *           *  \n");
	printf("*               *\n");
	printf("  *           * \n");
	printf("    *       *  \n");
	printf("      *   *   \n");
	printf("        *    \n");
	return 0;
}
